Gears from @rulecad/gears: print files (Bambu Studio 3MF, X1C, PLA, 0.2 mm layers). Every part checks printable with
no supports, flat side down as exported.

gear-sampler/     sampler (the plate) and sampler-gears (26 gears, dots on top = backlash: 1 dot 0.1 mm, 2 dots 0.2,
                  3 dots 0.3). Press each pair onto the pins its label names. Record: turns freely? play? teeth whole?
focus-slider/     rail (base), rack, pinion (knob on top). A 3 mm screw or pin through the pinion as its axle.
spool-winder/     winder-case, winder-ring, winder-sun, winder-gear (PRINT 3: the planets), winder-carrier (pins up),
                  winder-handle (press into the arm's end). The carrier goes on pins-down over the planets.
strap-tensioner/  tensioner-crank, tensioner-arm (slips onto the crank shaft's flat), tensioner-mid, tensioner-out
                  (gear, ratchet and spool), tensioner-pawl. 4 mm shafts. The pawl's seat is set by eye: try it.
